#!/bin/bash
g++ src.cpp